import {useParams} from "react-router-dom";
import {useEffect} from "react";

export function StudentUpdate() {
}
