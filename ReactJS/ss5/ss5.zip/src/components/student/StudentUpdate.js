import {useParams} from "react-router-dom";
import {useEffect} from "react";

export function StudentUpdate() {
    const param = useParams();
    param.id
}
